require 'rest-client'
require 'json'
system "clear"
banner = '''
3Xpl01T b0X By:
       .__    ____        _____  
  _____|  |__/_   |__  __/  |  | 
 /  ___/  |  \|   \  \/ /   |  |_
 \___ \|   Y  \   |\   /    ^   /
/____  >___|  /___| \_/\____   | 
     \/     \/              |__| 

'''

puts "\033[31m#{banner}\033[0m"
puts "[\033[36m+\033[0m] Escolha as opções"
puts [ nil, 
"[\033[36m+\033[0m] 1 - WordPress 4.7.0/4.7.1 Unauthenticated Content Injection  ", 
"[\033[36m+\033[0m] 2 - WordPress Plugin WP-Forum 1.7.8 - SQL Injection", 
"[\033[36m+\033[0m] 3 - ", 
"[\033[36m+\033[0m] 4 - ", 
"[\033[36m+\033[0m] 5 - "]
print "\n[\033[36m+\033[0m]===>\033[0m"  
begin
	escolha = gets.chomp.to_i

	if (escolha == 1)	
		system "ruby 1.rb" 
	elsif (escolha == 2)
		system "ruby 2.rb"
	else
		puts "Ainda fazendo!"
	end
rescue Interrupt => e
	puts "\n\n[\e[31m-\033[0m] Fechando programa\n "
end

